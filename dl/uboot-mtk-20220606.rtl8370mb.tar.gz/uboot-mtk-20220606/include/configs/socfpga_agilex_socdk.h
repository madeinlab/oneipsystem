/* SPDX-License-Identifier: GPL-2.0
 *
 * Copyright (C) 2019 Intel Corporation <www.intel.com>
 *
 */

#ifndef __CONFIG_SOCFGPA_AGILEX_H__
#define __CONFIG_SOCFGPA_AGILEX_H__

#include <configs/socfpga_soc64_common.h>

#endif	/* __CONFIG_SOCFGPA_AGILEX_H__ */
