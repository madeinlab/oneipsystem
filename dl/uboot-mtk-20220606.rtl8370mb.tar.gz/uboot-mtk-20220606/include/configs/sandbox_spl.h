/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (c) 2016 Google, Inc
 */

#ifndef __SANDBOX_SPL_CONFIG_H
#define __SANDBOX_SPL_CONFIG_H

#include <configs/sandbox.h>

#endif
