/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2015-2016 Marvell International Ltd.
 */

#ifndef _MVEBU_COMPHY_H_
#define _MVEBU_COMPHY_H_

int comphy_rx_training(struct udevice *dev, u32 lane);

#endif /* _MVEBU_COMPHY_H_ */
