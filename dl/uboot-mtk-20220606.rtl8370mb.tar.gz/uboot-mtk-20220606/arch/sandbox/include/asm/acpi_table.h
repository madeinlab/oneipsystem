/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2019 Google LLC
 */

#ifndef __ASM_ACPI_TABLE_H__
#define __ASM_ACPI_TABLE_H__

/* Empty for now, this file is required by acpi/acpi_table.h */

#endif /* __ASM_ACPI_TABLE_H__ */
