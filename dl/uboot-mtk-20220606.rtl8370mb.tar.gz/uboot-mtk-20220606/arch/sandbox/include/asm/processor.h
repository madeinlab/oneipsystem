/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (c) 2014 Google, Inc
 */

#ifndef _ASM_PROCESSOR_H
#define _ASM_PROCESSOR_H

/* This file is required for PCI */

#endif
