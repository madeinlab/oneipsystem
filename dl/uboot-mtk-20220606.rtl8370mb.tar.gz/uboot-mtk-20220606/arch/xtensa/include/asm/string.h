#ifndef _XTENSA_STRING_H
#define _XTENSA_STRING_H

/*
 * Use the generic string functions in U-Boot's lib_generic.
 * In the boot loader we care about compactness more than performance.
 * Prototypes will be taken from <linux/string.h>
 */

#endif	/* _XTENSA_STRING_H */
