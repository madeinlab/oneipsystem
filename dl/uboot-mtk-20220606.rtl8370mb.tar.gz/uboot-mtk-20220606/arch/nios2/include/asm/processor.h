/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * (C) Copyright 2004, Psyent Corporation <www.psyent.com>
 * Scott McNutt <smcnutt@psyent.com>
 */

#ifndef __ASM_NIOS2_PROCESSOR_H_
#define __ASM_NIOS2_PROCESSOR_H_
#endif /* __ASM_NIOS2_PROCESSOR_H_ */
