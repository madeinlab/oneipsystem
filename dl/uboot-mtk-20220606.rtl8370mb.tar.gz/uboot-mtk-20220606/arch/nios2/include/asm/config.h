/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2009 Freescale Semiconductor, Inc.
 */

#ifndef _ASM_CONFIG_H_
#define _ASM_CONFIG_H_

#endif
