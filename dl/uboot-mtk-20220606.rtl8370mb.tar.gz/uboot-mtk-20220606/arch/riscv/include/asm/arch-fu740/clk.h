/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (c) 2020-2021 SiFive Inc
 *
 * Authors:
 *   Pragnesh Patel <pragnesh.patel@sifive.com>
 */

#ifndef __CLK_SIFIVE_H
#define __CLK_SIFIVE_H

/* Note: This is a placeholder header for driver compilation. */

#endif
