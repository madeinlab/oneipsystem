/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * U-Boot - linkage.h
 *
 * Copyright (c) 2005-2007 Analog Devices Inc.
 */

#ifndef __ASM_LINKAGE_H
#define __ASM_LINKAGE_H

#endif
