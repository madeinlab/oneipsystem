/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (c) 2019 Western Digital Corporation or its affiliates.
 *
 * Authors:
 *   Anup Patel <anup.patel@wdc.com>
 */

#ifndef __ASM_RISCV_ARCH_CLK_H
#define __ASM_RISCV_ARCH_CLK_H

/* Note: This is a placeholder header for driver compilation. */

#endif
