/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2018 SiFive, Inc.
 */

#include <asm-generic/gpio.h>
