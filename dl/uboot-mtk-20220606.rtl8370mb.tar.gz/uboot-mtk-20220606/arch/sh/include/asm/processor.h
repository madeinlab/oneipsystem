#ifndef _ASM_SH_PROCESSOR_H_
#define _ASM_SH_PROCESSOR_H_
# include <asm/cpu_sh4.h>
#endif
