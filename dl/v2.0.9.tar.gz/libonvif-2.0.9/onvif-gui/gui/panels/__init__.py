from .camerapanel import CameraPanel
from .filepanel import FilePanel
from .videopanel import VideoPanel
from .settingspanel import SettingsPanel
from .audiopanel import AudioPanel