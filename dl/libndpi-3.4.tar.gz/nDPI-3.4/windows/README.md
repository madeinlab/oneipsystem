# Building on Windows

This directory contains windows-specific files. In particular:
- nDPI.vcxproj is a sample project for nDPI. Use it as starting point for compiling on Windows. Note that it might be outdated as new protocols are added to nDPI
